import pr1 from '../img/pr1.jpg';
import pr2 from '../img/pr2.jpg';
import pr3 from '../img/pr3.jpg';
import pr4 from '../img/pr4.jpg';
import pr5 from '../img/pr5.jpg';
import pr6 from '../img/pr6.jpg';
import pr7 from '../img/pr7.jpg';
import pr8 from '../img/pr8.jpg';
import pr9 from '../img/pr9.jpg';
import pr10 from '../img/pr10.jpg';
import pr11 from '../img/pr11.jpg';
import pr12 from '../img/pr12.jpg';
export const Listproduct=[
    {
        Id:'1',
        Image:pr1,
        Name:'King UV germicidal lamp1',
        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'2',
        Image:pr2,
        Name:'King UV germicidal lamp2',
        Origin:'France',

        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'3',
        Image:pr3,
        Name:'King UV germicidal lamp3',

        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'4',
        Image:pr4,
        Name:'King UV germicidal lamp4',

        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'5',
        Image:pr5,
        Name:'King UV germicidal lamp5',

        Origin:'France',

        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'6',
        Image:pr6,
        Name:'King UV germicidal lamp6',
        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'7',
        Image:pr7,
        Name:'King UV germicidal lamp7',
        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'8',
        Image:pr8,
        Name:'King UV germicidal lamp8',
        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'9',
        Image:pr9,
        Name:'King UV germicidal lamp9',

        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'10',
        Image:pr10,
        Name:'King UV germicidal lamp10',

        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'11',
        Image:pr11,
        Name:'King UV germicidal lamp11',
        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },

    {
        Id:'12',
        Image:pr12,
        Name:'King UV germicidal lamp12',

        Origin:'France',
        Category:'',
        Price: '300.000',
        Information: 'Aquarium machine is a device that helps circulate water, provide oxygen and maintain a stable living environment for fish and plants in the aquarium. It supports water filtration, detoxification and ensures flow.',
        Rating: '5 star',
    },
]