
import ca6 from '../img/nw0.jpg';
import ca7 from '../img/nw1.jpg';
import ca8 from '../img/nw2.jpg';
import ca9 from '../img/nw3.jpg';
import ca10 from '../img/ca9.jpg';
import ca11 from '../img/ca11.jpg';
import ca12 from '../img/ca12.jpg';
import ca13 from '../img/ca13.jpg';



export const News=[
    {
        Id:'1',
        Image:ca6,
    },
    {
        Id:'2',
        Image:ca7,
    },
    {
        Id:'3',
        Image:ca8,
    },
    {
        Id:'4',
        Image:ca9,
    },
    {
        Id:'5',
        Image:ca10,
    },
    {
        Id:'6',
        Image:ca11,
    },
    {
        Id:'7',
        Image:ca12,
    },
    {
        Id:'8',
        Image:ca13,
    },

]