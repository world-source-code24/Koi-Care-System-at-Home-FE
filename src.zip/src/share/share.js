import img1 from '../img/a10.jpg';
import img2 from '../img/a7.jpg';
import img3 from '../img/a3.jpg';
import img4 from '../img/a4.jpg';
import img5 from '../img/a8.jpg';
import img6 from '../img/a6.jpg';
// import ca6 from '../img/ca6.jpg';
// import ca7 from '../img/ca7.jpg';
// import ca8 from '../img/ca8.jpg';
// import ca9 from '../img/ca9.jpg';



export const FishBG=[
    {
        Id:'1',
        Image:img1,
    },
    {
        Id:'2',
        Image:img2,
    },
    {
        Id:'3',
        Image:img3,
    },
    {
        Id:'4',
        Image:img4,
    },
    {
        Id:'5',
        Image:img5,
    },
    {
        Id:'6',
        Image:img6,
    },

]