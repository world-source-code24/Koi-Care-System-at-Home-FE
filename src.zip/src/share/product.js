import pr1 from '../img/pr1.jpg';
import pr2 from '../img/pr2.jpg';
import pr3 from '../img/pr3.jpg';
import pr4 from '../img/pr4.jpg';
import pr5 from '../img/pr5.jpg';
import pr6 from '../img/pr6.jpg';
import pr7 from '../img/pr7.jpg';
import pr8 from '../img/pr8.jpg';
import pr9 from '../img/pr9.jpg';
import pr10 from '../img/pr10.jpg';
import pr11 from '../img/pr11.jpg';
import pr12 from '../img/pr12.jpg';
export const Products=[
    {
        Id:'1',
        Image:pr1,
        Name:'King UV germicidal lamp',
        Origin:'',
        Category:'',
        Price: '300.000 VND'
    },

    {
        Id:'2',
        Image:pr2,
        Name:'King UV germicidal lamp',
        Origin:'',
        Category:'',
        Price: '300.000 VND'
    },

    {
        Id:'3',
        Image:pr3,
        Name:'King UV germicidal lamp',
        Origin:'',
        Category:'',
        Price: '300.000 VND'
    },

    {
        Id:'4',
        Image:pr4,
        Name:'King UV germicidal lamp',
        Origin:'',
        Category:'',
        Price: '300.000 VND'
    },

    // {
    //     Id:'5',
    //     Image:pr5,
    //     Name:'Product5',
    //     Origin:'',
    //     Category:'',
    // },

    // {
    //     Id:'6',
    //     Image:pr6,
    //     Name:'Product6',
    //     Origin:'',
    //     Category:'',
    // },

    // {
    //     Id:'7',
    //     Image:pr7,
    //     Name:'Product7',
    //     Origin:'',
    //     Category:'',
    // },

    // {
    //     Id:'8',
    //     Image:pr8,
    //     Name:'Product8',
    //     Origin:'',
    //     Category:'',
    // },

    // {
    //     Id:'8',
    //     Image:pr9,
    //     Name:'Product9',
    //     Origin:'',
    //     Category:'',
    // },

    // {
    //     Id:'8',
    //     Image:pr10,
    //     Name:'Product10',
    //     Origin:'',
    //     Category:'',
    // },

    // {
    //     Id:'8',
    //     Image:pr11,
    //     Name:'Product11',
    //     Origin:'',
    //     Category:'',
    // },

    // {
    //     Id:'8',
    //     Image:pr12,
    //     Name:'Product12',
    //     Origin:'',
    //     Category:'',
    // },
]