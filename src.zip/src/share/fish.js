
import ca6 from '../img/ca6.jpg';
import ca7 from '../img/ca7.jpg';
import ca8 from '../img/ca8.jpg';
import ca9 from '../img/ca9.jpg';
import ca10 from '../img/ca14.jpg';
import ca11 from '../img/ca11.jpg';
import ca12 from '../img/ca12.jpg';
import ca13 from '../img/ca13.jpg';



export const Fish=[
    {
        Id:'1',
        Image:ca6,
    },
    {
        Id:'2',
        Image:ca7,
    },
    {
        Id:'3',
        Image:ca8,
    },
    {
        Id:'4',
        Image:ca9,
    },
    {
        Id:'5',
        Image:ca10,
    },
    {
        Id:'6',
        Image:ca11,
    },
    {
        Id:'7',
        Image:ca12,
    },
    {
        Id:'8',
        Image:ca13,
    },

]